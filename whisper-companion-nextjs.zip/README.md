# Whisper Companion
A quiet, reflective chatbot built with Next.js and GPT.