# Whisper Companion
A quiet, reflective GPT-based chatbot designed for empathy and presence.